** ON INSTALL **
Open a command prompt
- run 'npm update'
- run 'npm install'

** TO START THE PROJECT **
- run 'npm run dev'
- go to localhost:3000 in your browser