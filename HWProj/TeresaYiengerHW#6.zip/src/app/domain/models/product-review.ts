
export class ProductReview{
  userName:string;
  rating:number;
  date:Date;
  comment:string;
}
